package library.management.system;

import javax.swing.JOptionPane;

public class BookHashTable {
    private Book[] hashArray; // Array to store books
    private int arraySize; // Size of the hash table

    // Constructor to initialize the hash table
    public BookHashTable(int size) {
        arraySize = size;
        hashArray = new Book[arraySize];
    }

    // Hash function to calculate the index
    private int hashFunc1(String isbn) {
        return Math.abs(isbn.hashCode()) % arraySize;
    }

    // Insert a book into the hash table
    public void insert(Book book) {
        int hashVal = hashFunc1(book.getIsbn()); // Get index from hash function
        while (hashArray[hashVal] != null) { // Handle collision with linear probing
            hashVal++;
            hashVal %= arraySize; // Wrap around if needed
        }
        hashArray[hashVal] = book; // Insert the book
    }

    // Find a book by its ISBN
    public Book find(String isbn) {
        int hashVal = hashFunc1(isbn); // Get index from hash function
        while (hashArray[hashVal] != null) {
            if (hashArray[hashVal].getIsbn().equals(isbn)) {
                return hashArray[hashVal]; // Book found
            }
            hashVal++;
            hashVal %= arraySize; // Wrap around if needed
        }
        return null; // Book not found
    }

    // Get all books in the hash table
    public Book[] getAllBooks() {
        return hashArray; // Return the internal array
    }

    // Display all books in a message dialog
    public void displayAllBooks() {
        StringBuilder bookList = new StringBuilder(); // String to store book details

        for (Book book : hashArray) { // Iterate through the hash table
            if (book != null) { // Only include non-null entries
                bookList.append("ISBN: ").append(book.getIsbn())
                        .append(", Title: ").append(book.getTitle())
                        .append(", Author: ").append(book.getAuthor())
                        .append("\n");
            }
        }

        // Show the book list in a dialog box
        if (bookList.length() == 0) {
            JOptionPane.showMessageDialog(null, "No books available.", "Book Inventory", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, bookList.toString(), "Book Inventory", JOptionPane.INFORMATION_MESSAGE);
        }
    }
  
    // Issue a book based on ISBN
    public boolean issueBook(String isbn) {
        int hashVal = hashFunc1(isbn);  // Calculate the hash index based on ISBN

        // Search for the book in the hash table
        while (hashArray[hashVal] != null) {
            if (hashArray[hashVal].getIsbn().equals(isbn)) {
                if (hashArray[hashVal].isIssued()) {
                    return false;  // Book is already issued
                }
                // If the book is available, mark it as issued
                hashArray[hashVal].setIssued(true);
                return true;
            }
            hashVal++;
            hashVal %= arraySize;  // Handle wrap-around
        }
        return false;  // Book not found or not available
    }


     private void remove(int hashVal) {
    hashArray[hashVal] = null; // Remove the book

    // Reinsert the subsequent entries to prevent issues in the hash table
    int nextSlot = (hashVal + 1) % arraySize;
    while (hashArray[nextSlot] != null) {
        Book temp = hashArray[nextSlot];
        hashArray[nextSlot] = null; // Temporarily remove
        insert(temp); // Reinsert to ensure correct placement
        nextSlot = (nextSlot + 1) % arraySize;
    }
}
     
     public boolean returnBook(Book book) {
    int hashVal = hashFunc1(book.getIsbn()); // Calculate the hash value
    while (hashArray[hashVal] != null) { // Search for the book in the hash table
        if (hashArray[hashVal].getIsbn().equals(book.getIsbn())) { // Check ISBN match
            if (hashArray[hashVal].isIssued()) { // Check if the book is issued
                hashArray[hashVal].setIssued(false); // Mark the book as returned
                return true; // Return success
            } else {
                return false; // Book exists but is not issued
            }
        }
        hashVal++;
        hashVal %= arraySize; // Handle wrap-around
    }
    return false; // Book not found in the hash table
}
//     public boolean returnBook(Book book) {
//    // Check if the book is null
//    if (book == null || book.getIsbn() == null) {
//        return false;
//    }
//
//    // Search for the book to ensure it was issued
//    Book issuedBook = find(book.getIsbn());
//    if (issuedBook != null && issuedBook.isIssued()) {
//        book.setIssued(false); // Mark the book as not issued
//        insert(book); // Reinsert the book into the hash table
//        return true; // Book successfully returned
//    }
//
//    return false; // Book not found or not issued
//}
     public Book[] getIssuedBooks() {
    // Temporary list to collect issued books
    Book[] tempArray = new Book[arraySize]; 
    int count = 0;

    // Iterate through the hash array
    for (Book book : hashArray) {
        if (book != null && book.isIssued()) {
            tempArray[count++] = book; // Add to the temporary array
        }
    }

    // Create a new array with exact size to hold issued books
    Book[] issuedBooks = new Book[count];
    System.arraycopy(tempArray, 0, issuedBooks, 0, count);

    return issuedBooks; // Return the array of issued books
}


}
