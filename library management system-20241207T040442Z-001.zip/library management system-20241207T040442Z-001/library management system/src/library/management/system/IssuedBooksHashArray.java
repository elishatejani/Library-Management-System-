/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.management.system;

/**
 *
 * @author HP
 */
public class IssuedBooksHashArray {
        private IssuedBook[] hashArray; // Array to store issued books
    private int arraySize; // Size of the hash table

    // Constructor to initialize the hash table
    public IssuedBooksHashArray(int size) {
        arraySize = size;
        hashArray = new IssuedBook[arraySize];
    }

    // Hash function to calculate the index
    private int hashFunc1(String isbn) {
        return Math.abs(isbn.hashCode()) % arraySize;
    }

    // Add an issued book to the hash table
    public boolean issueBook(String isbn, Book book, String studentId) {
        int hashVal = hashFunc1(isbn); // Calculate hash index

        // Search for a free slot using linear probing
        while (hashArray[hashVal] != null) {
            if (hashArray[hashVal].getBook().getIsbn().equals(isbn)) {
                return false; // Book is already issued
            }
            hashVal++;
            hashVal %= arraySize; // Handle wrap-around
        }

        // Add issued book to the hash table
        hashArray[hashVal] = new IssuedBook(book, studentId);
        return true; // Successfully issued
    }

    // Remove an issued book (return book)
    public boolean returnBook(String isbn) {
        int hashVal = hashFunc1(isbn); // Calculate hash index

        // Search for the book to remove
        while (hashArray[hashVal] != null) {
            if (hashArray[hashVal].getBook().getIsbn().equals(isbn)) {
                hashArray[hashVal] = null; // Remove the book
                rehash(hashVal); // Rehash subsequent entries to maintain consistency
                return true; // Successfully returned
            }
            hashVal++;
            hashVal %= arraySize; // Handle wrap-around
        }
        return false; // Book not found
    }

    // Rehash books to fill gaps caused by removal
    private void rehash(int startIndex) {
        int hashVal = (startIndex + 1) % arraySize;

        while (hashArray[hashVal] != null) {
            IssuedBook temp = hashArray[hashVal];
            hashArray[hashVal] = null;
            insertRehashed(temp);
            hashVal++;
            hashVal %= arraySize;
        }
    }

    // Reinsert a book during rehashing
    private void insertRehashed(IssuedBook issuedBook) {
        int hashVal = hashFunc1(issuedBook.getBook().getIsbn());
        while (hashArray[hashVal] != null) {
            hashVal++;
            hashVal %= arraySize; // Handle wrap-around
        }
        hashArray[hashVal] = issuedBook;
    }

    // Check if a book is issued
    public boolean isBookIssued(String isbn) {
        int hashVal = hashFunc1(isbn); // Calculate hash index

        // Search for the book
        while (hashArray[hashVal] != null) {
            if (hashArray[hashVal].getBook().getIsbn().equals(isbn)) {
                return true; // Book is issued
            }
            hashVal++;
            hashVal %= arraySize; // Handle wrap-around
        }
        return false; // Book not found
    }

    // Get all issued books
    public IssuedBook[] getIssuedBooks() {
        IssuedBook[] tempArray = new IssuedBook[arraySize];
        int count = 0;

        for (IssuedBook issuedBook : hashArray) {
            if (issuedBook != null) {
                tempArray[count++] = issuedBook;
            }
        }

        // Create a new array with exact size
        IssuedBook[] issuedBooks = new IssuedBook[count];
        System.arraycopy(tempArray, 0, issuedBooks, 0, count);

        return issuedBooks;
    }
    
}
