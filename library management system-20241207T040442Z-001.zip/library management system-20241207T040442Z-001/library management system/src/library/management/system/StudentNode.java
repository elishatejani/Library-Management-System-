/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.management.system;

/**
 *
 * @author LENOVO
 */
public class StudentNode {
    String name, id;
    StudentNode next;

    StudentNode(String name, String id) {
        this.name = name;
        this.id = id;
        this.next = null;
    }


// StudentList.java

}
