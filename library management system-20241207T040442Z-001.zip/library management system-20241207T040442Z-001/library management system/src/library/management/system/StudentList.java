package library.management.system;

import javax.swing.JOptionPane;




/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LENOVO
 */

   public class StudentList {
    private StudentNode head;
    public StudentList() {
        head = null;
        // Pre-populating with some students
        insertAtBeginning("Alice Johnson", "S001");
        insertAtBeginning("Bob Smith", "S002");
        insertAtBeginning("Charlie Brown", "S003");
    }

    public void insertAtBeginning(String name, String id) {
        
        if (studentExists(id)) {
            // Show message if student with the same ID already exists
            JOptionPane.showMessageDialog(null, "Student with this ID already exists.");
            return;  // Do not add the student if ID already exists
        }
        else{
        
        // Create a new student node
        StudentNode newNode = new StudentNode(name, id);
        // Insert at the beginning of the list
        newNode.next = head;
        head = newNode;}
    }

    public String traverse() {
        StringBuilder studentList = new StringBuilder();
        StudentNode current = head;
        while (current != null) {
            studentList.append("Name: ").append(current.name).append(", ID: ").append(current.id).append("\n");
            current = current.next;
        }
        return studentList.toString();
    }
     private boolean studentExists(String id) {
        StudentNode current = head;
        while (current != null) {
            if (current.id.equals(id)) {
                return true;  // Student with the same ID found
            }
            current = current.next;
        }
        return false;  // No student with the same ID found
    }
}
    

