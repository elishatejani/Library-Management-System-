/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package library.management.system;

/**
 *
 * @author HP
 */


public class IssuedBook {
    private Book book; // The book that is issued
    private String studentId; // ID of the student who issued the book

    // Constructor
    public IssuedBook(Book book, String studentId) {
        this.book = book;
        this.studentId = studentId;
    }

    // Getter for book
    public Book getBook() {
        return book;
    }

    // Setter for book
    public void setBook(Book book) {
        this.book = book;
    }

    // Getter for studentId
    public String getStudentId() {
        return studentId;
    }

    // Setter for studentId
    public void setStudentId(String studentId) {
        this.studentId = studentId;
    }
}
